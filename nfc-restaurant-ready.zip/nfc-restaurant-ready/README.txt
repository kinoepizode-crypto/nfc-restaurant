NFC RESTAURANT READY FILES

These are replacement HTML files for the existing repository.
- index.html: public restaurant page
- owner.html: owner login and editing page with error/timeout handling

Upload/replace both files in the repository root (same level as README.md), commit the changes, and Vercel should redeploy.
Note: owner.html currently displays the slug as demo-restaurant because the businesses table query does not retrieve slug in the current select. If using other restaurant records, update the select to include slug.
